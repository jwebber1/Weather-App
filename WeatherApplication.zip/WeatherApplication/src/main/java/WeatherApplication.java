
        import javafx.application.Application;
        import javafx.event.ActionEvent;
        import javafx.event.EventHandler;
        import javafx.geometry.HPos;
        import javafx.geometry.Insets;
        import javafx.scene.Scene;
        import javafx.scene.control.Button;
        import javafx.scene.control.Label;
        import javafx.scene.control.TextArea;
        import javafx.scene.control.TextField;
        import javafx.scene.image.Image;
        import javafx.scene.image.ImageView;
        import javafx.scene.layout.GridPane;
        import javafx.stage.Stage;
        import javafx.scene.text.*;
        import org.jsoup.Jsoup;
        import org.jsoup.nodes.Document;
        import org.jsoup.parser.Parser;

        import java.io.*;
        import java.net.URL;

public class WeatherApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Weather Report Application");

        //creating layout of Scene
        GridPane layout = new GridPane();
        layout.setPadding(new Insets(10));
        layout.setHgap(5);
        layout.setVgap(20);

        //middle left for city name
        Label txtLabel_0 = new Label("Please enter your city name: ");
        GridPane.setConstraints(txtLabel_0,0,0);
        GridPane.setColumnSpan(txtLabel_0,1);
        GridPane.setMargin(txtLabel_0, new Insets(0,0,0,0));
        layout.getChildren().add(txtLabel_0);

        //next column textfield for city
        final TextField inputCity = new TextField();
        inputCity.setPromptText("City");
        inputCity.setPrefColumnCount(10);
        GridPane.setHalignment(inputCity, HPos.RIGHT);
        GridPane.setConstraints(inputCity,0,1);
        GridPane.setMargin(inputCity, new Insets(0,5,0,0));
        layout.getChildren().add(inputCity);


        //top left label for state abbreviation
        Label txtLabel_1 = new Label("Please enter the your state abbreviation: ");
        GridPane.setConstraints(txtLabel_1,0,2);
        GridPane.setColumnSpan(txtLabel_1,1);
        GridPane.setMargin(txtLabel_1, new Insets(0,0,0,0));
        layout.getChildren().add(txtLabel_1);


        //next column textfield for state
        final TextField inputState = new TextField();
        inputState.setPromptText("ST");
        inputState.setPrefColumnCount(10);
        GridPane.setHalignment(inputState, HPos.RIGHT);
        GridPane.setConstraints(inputState,0,3);
        GridPane.setMargin(inputState, new Insets(0,5,0,0));
        layout.getChildren().add(inputState);

        //textfield for output
        final TextArea outputArea = new TextArea();
        outputArea.setPrefWidth(575);
        GridPane.setConstraints(outputArea, 1,0, 1, 5);
        GridPane.setMargin(outputArea, new Insets(0,0,0,5));
        layout.getChildren().add(outputArea);


        //Lastly, a button in the bottom right
        Button getWeather = new Button("Get Weather");
        GridPane.setConstraints(getWeather,0,4);
        GridPane.setHalignment(getWeather, HPos.LEFT);
        GridPane.setMargin(txtLabel_0, new Insets(0,0,0,0));
        layout.getChildren().add(getWeather);

        //set the button's action
        getWeather.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                if(inputCity.getLength() == 0){
                    outputArea.setText("Please enter a city name.");
                }
                else if(inputState.getLength() != 2){
                    outputArea.setText("Please enter a state abbreviation of length 2.");
                }
                else{
                    //getting state abbreviation and city
                    String stateAbbrev = inputState.getText().toUpperCase();
                    String city = formatCity(inputCity.getText());

                    //format string for the website to scrape
                    String urlString = String.format(
                            "http://api.wunderground.com/api/9db68defb9972483/conditions/q/%s/%s.xml",
                            stateAbbrev,city);

                    //get the data from the website
                    String xml = readFromURL(urlString);
                    Document doc = Jsoup.parse(xml,"", Parser.xmlParser());

                    //Query strings for the website and error handling
                    try {
                        String xmlCity = doc.select("city").first().text();
                        String xmlState = doc.select("state_name").first().text();
                        String xmlTime = doc.select("observation_time")
                                .first().text().replaceAll("Last Updated on ", "");
                        String xmlWeather = doc.select("weather").first().text().toLowerCase();
                        String xmlTemperature = doc.select("temperature_string").first().text();
                        String xmlWindChill = doc.select("windchill_string").first().text();
                        if(xmlWindChill.equals("NA")) {xmlWindChill = "the same";}
                        String xmlVisMiles = doc.select("visibility_mi").first().text();
                        String xmlVisKilos = doc.select("visibility_km").first().text();
                        String xmlHumidity = doc.select("relative_humidity").first().text();
                        String xmlPrecipToday = doc.select("precip_today_string").first().text();
                        if(xmlPrecipToday.startsWith("-")){ xmlPrecipToday = "0";}
                        String xmlPrecipHr = doc.select("precip_1hr_string").first().text();
                        if(xmlPrecipHr.startsWith("-")){ xmlPrecipHr = "0";}
                        String xmlWindDirection = doc.select("wind_dir").first().text();
                        String xmlWindMPH = doc.select("wind_mph").first().text();
                        String xmlWindKMH = doc.select("wind_kph").first().text();


                        //display in the outputArea
                        outputArea.setText("Current weather in "+xmlCity+", "+xmlState+" on "+xmlTime+"\n"+
                                "-------------------------------------------------------------------------\n"+
                                "Currently "+xmlWeather+" with a temperature of "+xmlTemperature+" and wind chill of "+xmlWindChill+".\n"+
                                "Visibility of "+xmlVisMiles+" miles ("+xmlVisKilos+" kilometers).\n"+
                                "Relative humidity of "+xmlHumidity+" with precipitation today of "+xmlPrecipToday+", "+xmlPrecipHr+" in the last hour.\n"+
                                "Wind coming from the "+xmlWindDirection+" at "+xmlWindMPH+" mph ("+xmlWindKMH+" kph).\n"+
                                "Weather brought to you by Weather Underground, \n"+
                                doc.select("link").first().text()+".");

                    }
                    catch(NullPointerException e){
                        outputArea.setText("Could not find given city and state.");
                    }
                }
            }
        });

        String urlString = "http://api.wunderground.com/api/9db68defb9972483/conditions/q/MO/Palmyra.xml";
        String xml = readFromURL(urlString);
        Document doc = Jsoup.parse(xml,"", Parser.xmlParser());
        String imageURL = doc.select("url").first().text();
        Image WUlogo = new Image(imageURL);

        ImageView logo = new ImageView();
        logo.setImage(WUlogo);
        logo.setFitWidth(100);
        logo.setFitHeight(100);
        logo.setPreserveRatio(true);
        logo.setSmooth(true);
        GridPane.setConstraints(logo, 1, 4);
        GridPane.setHalignment(logo, HPos.RIGHT);
        layout.getChildren().add(logo);




        Scene mainScene = new Scene(layout, 775, 250);
        primaryStage.setScene(mainScene);
        primaryStage.show();
    }


    //formatter for the city string
    public static String formatCity(String str){
        String city = "";
        String temp = str.toLowerCase();

        //error handling for "st." or "st"
        if(str.startsWith("st")){
            temp = "saint"+str.substring(2);
        }
        if(str.startsWith("st.")){
            temp = "saint"+str.substring(3);
        }

        //capitalize first letter of city and after spaces
        for(int i = 0; i<temp.length(); i++){
            if(i == 0 || temp.charAt(i-1) == ' '){
                city += String.valueOf(temp.charAt(i)).toUpperCase();
            }
            else{
                city += temp.charAt(i);
            }
        }

        return city.replace(' ','_');
    }

    //method to grab info from website
    public static String readFromURL(String urlString){
        String data = "";

        try {
            URL url = new URL(urlString);
            BufferedReader input = new BufferedReader(
                    new InputStreamReader(url.openStream()));
            String str;
            while((str = input.readLine()) != null) {
                data += str;
            }
            input.close();
        }
        catch (Exception e){
            System.err.println(e.getMessage());
        }
        return data;
    }
}
